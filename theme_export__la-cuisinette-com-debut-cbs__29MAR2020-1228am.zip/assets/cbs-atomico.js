function WebComponent(){
    return atomico.html`<host></host>`
}
atomico.customElement("my-tag",WebComponent);

